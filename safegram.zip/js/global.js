$(document).ready(function () {
  /*------*/
  $(".haschild_menuone").click(function () {
    var x = $(window).width();
    if (x < 1080) {
      $(this).find(".submenu_levelone").slideToggle();
    }
  });
  $(".haschild_menutwo").click(function () {
    var x = $(window).width();
    if (x < 1080) {
      $(this).find(".submenu_leveltwo").slideToggle();
    }
  });

  $(".submenu_levelone li").click(function (e) {
    e.stopPropagation();
  });

  /*-----*/
  $(".mobile_menuicon").click(function () {
    //$(this).toggleClass("active_menuicon");
    $(".header_items>nav>ul").toggleClass("active_nav");
  });
  $(".mobile_close").click(function () {
    $(".header_items>nav>ul").removeClass("active_nav");
  });

  /*-----------*/
  $("body").click(function (event) {
    if ($(".header_items>nav>ul").hasClass("active_nav")) {
      $(".header_items>nav>ul").removeClass("active_nav");
    }
  });
  $(".mobile_menuicon,.header_items>nav>ul").click(function (event) {
    event.stopPropagation();
  });

  $('.dropdown-submenu a.test').on("click", function (e) {
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
});
